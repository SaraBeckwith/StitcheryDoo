{
		'manufacturer': 'DMC',
		'threadID': '',
		'hexvalue': '',
		'colordesc': ''
	},